import React from 'react';
import './App.css';

function App() {
  return (
    <div className="bg-white text-gray-800">
      <section className="bg-cover bg-center text-white py-20 text-center" style={{ backgroundImage: "url('/ai-model.jpg')" }}>
        <h1 className="text-4xl md:text-6xl font-bold mb-4">Bulk Women's Fashion</h1>
        <p className="text-xl md:text-2xl">Direct from Manufacturer</p>
        <button className="mt-6 bg-black text-white px-6 py-3 rounded-lg text-lg">View Catalogue</button>
      </section>

      <section className="py-12 px-6 md:px-20">
        <h2 className="text-3xl font-bold mb-8 text-center">Product Categories</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {['Eastern Kurtis', 'Western Dresses', 'Co-ord Sets', 'Tops'].map((category) => (
            <div key={category} className="text-center py-6 shadow-md border rounded-lg">
              <h3 className="text-xl font-semibold">{category}</h3>
            </div>
          ))}
        </div>
      </section>

      <section className="py-12 px-6 md:px-20 bg-gray-100">
        <h2 className="text-3xl font-bold mb-8 text-center">Featured Products</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[160, 220, 300].map((price, index) => (
            <div key={index} className="shadow-xl border rounded-lg overflow-hidden">
              <img
                src={`/product${index + 1}.jpg`}
                alt={`Product ${index + 1}`}
                className="w-full h-60 object-cover"
              />
              <div className="p-4">
                <h3 className="text-lg font-semibold mb-2">Product Name</h3>
                <p>Price: ₹{price}</p>
                <p>MOQ: {price === 300 ? 25 : 50} pcs</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="py-12 px-6 md:px-20">
        <h2 className="text-3xl font-bold mb-8 text-center">Why Choose Us</h2>
        <ul className="grid md:grid-cols-2 gap-4 text-lg list-disc list-inside">
          <li>Fast shipping</li>
          <li>Low MOQ</li>
          <li>Custom designs available</li>
          <li>AI model photography</li>
        </ul>
      </section>

      <section className="py-12 px-6 md:px-20 bg-pink-50">
        <h2 className="text-3xl font-bold mb-8 text-center">Style Inspiration</h2>
        <p className="text-center text-gray-600">Follow us on Instagram for daily style ideas and trends!</p>
      </section>

      <section className="py-12 px-6 md:px-20 bg-gray-100">
        <h2 className="text-3xl font-bold mb-8 text-center">Business Inquiry</h2>
        <form className="grid gap-6 max-w-xl mx-auto">
          <input type="text" placeholder="Name" className="border p-3 rounded" required />
          <input type="text" placeholder="Company Name" className="border p-3 rounded" required />
          <input type="tel" placeholder="WhatsApp Number" className="border p-3 rounded" required />
          <input type="number" placeholder="Quantity Needed" className="border p-3 rounded" required />
          <button type="submit" className="bg-black text-white px-6 py-3 rounded-lg">Submit Inquiry</button>
        </form>
      </section>

      <footer className="py-8 px-6 md:px-20 bg-black text-white text-center">
        <p>📞 Phone: 8657194488</p>
        <p>📧 Email: sbzsk90@gmail.com</p>
        <p>📍 Location: Bandra (E), Mumbai</p>
        <p>💬 WhatsApp: 8657194488</p>
        <p className="mt-4 text-sm">© {new Date().getFullYear()} Chief</p>
      </footer>
    </div>
  );
}

export default App;
